﻿using System;

namespace Observer
{
    public class Class1
    {
    }
}
